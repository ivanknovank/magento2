define([
    'uiComponent'

], function (Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Dev_CheckoutFields/summary/donate'
        }
    });
});
