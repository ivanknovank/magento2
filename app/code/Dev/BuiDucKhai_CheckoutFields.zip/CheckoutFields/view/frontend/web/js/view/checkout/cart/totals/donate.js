define(
    [
        'Dev_CheckoutFields/js/view/checkout/summary/donate'
    ],
    function (Component) {
        'use strict';
        return Component.extend({
            isDisplayed: function () {
                return true;
            }
        });
    }
);
