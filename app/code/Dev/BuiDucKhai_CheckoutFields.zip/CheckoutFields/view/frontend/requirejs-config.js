var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Dev_CheckoutFields/js/model/shipping-save-processor/default'
        }
    }
};
